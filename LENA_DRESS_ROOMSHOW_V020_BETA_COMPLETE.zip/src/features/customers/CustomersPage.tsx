import { useMemo, useState } from 'react';
import { CircleAlert, Plus, Search } from 'lucide-react';
import { PageHeader } from '../../components/shared/PageHeader';
import { SummaryCard } from '../../components/shared/SummaryCard';
import { formatMoneyOMR } from '../../shared/utils/format';
import { AddCustomerModal } from './AddCustomerModal';
import { filterCustomers, getCustomers, summarizeCustomers } from './customer.service';
import type { Customer, CustomerFilters, CustomerStatus } from './customer.types';

const statusLabels: Record<CustomerStatus, string> = {
  normal: 'عادية',
  trusted: 'موثوقة',
  warning: 'تنبيه',
  blocked: 'محظورة',
};

const statusStyles: Record<CustomerStatus, string> = {
  normal: 'bg-slate-100 text-slate-700 ring-slate-200',
  trusted: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  warning: 'bg-amber-50 text-amber-700 ring-amber-200',
  blocked: 'bg-rose-50 text-rose-700 ring-rose-200',
};

const statuses: Array<'all' | CustomerStatus> = ['all', 'normal', 'trusted', 'warning', 'blocked'];

function CustomerCard({ customer }: { customer: Customer }) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-slate-400" dir="ltr">{customer.phone}</p>
          <h2 className="mt-1 text-xl font-bold text-slate-950">{customer.name}</h2>
          {customer.address && <p className="mt-1 text-sm text-slate-500">{customer.address}</p>}
        </div>
        <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold ring-1 ${statusStyles[customer.status]}`}>
          {statusLabels[customer.status]}
        </span>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl bg-stone-50 p-3">
          <p className="text-sm text-slate-400">الحجوزات</p>
          <p className="mt-1 font-bold text-slate-950">{customer.totalReservations}</p>
        </div>
        <div className="rounded-xl bg-stone-50 p-3">
          <p className="text-sm text-slate-400">النشطة</p>
          <p className="mt-1 font-bold text-slate-950">{customer.activeReservations}</p>
        </div>
        <div className="rounded-xl bg-stone-50 p-3">
          <p className="text-sm text-slate-400">المتبقي</p>
          <p className={`mt-1 font-bold ${customer.remainingBalance > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
            {formatMoneyOMR(customer.remainingBalance)}
          </p>
        </div>
      </div>

      <div className="mt-5 border-t border-slate-100 pt-4 text-sm leading-6 text-slate-600">
        <p><span className="font-semibold text-slate-900">المقاسات:</span> {customer.measurements || 'غير مسجلة'}</p>
        {customer.lastReservationDate && (
          <p className="mt-2"><span className="font-semibold text-slate-900">آخر حجز:</span> {customer.lastReservationDate}</p>
        )}
        {customer.notes && <p className="mt-2 rounded-xl bg-amber-50 p-3 text-amber-900">{customer.notes}</p>}
      </div>
    </article>
  );
}

export function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>(() => getCustomers());
  const [filters, setFilters] = useState<CustomerFilters>({ search: '', status: 'all', balance: 'all' });
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const filteredCustomers = useMemo(() => filterCustomers(customers, filters), [customers, filters]);
  const summary = useMemo(() => summarizeCustomers(customers), [customers]);

  const handleCreated = (customer: Customer) => {
    setCustomers((current) => [customer, ...current]);
    setFeedback(`تمت إضافة العميلة ${customer.name} بنجاح.`);
  };

  return (
    <section className="space-y-6">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <PageHeader
          eyebrow="العميلات"
          title="إدارة العميلات"
          description="حفظ بيانات التواصل والمقاسات وحالة التعامل والأرصدة في سجل واحد واضح."
        />
        <button
          type="button"
          onClick={() => {
            setFeedback(null);
            setShowCreateModal(true);
          }}
          className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2"
        >
          <Plus aria-hidden="true" className="h-5 w-5" />
          إضافة عميلة
        </button>
      </div>

      {feedback && (
        <div role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-800">
          {feedback}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <SummaryCard label="إجمالي العميلات" value={summary.total} />
        <SummaryCard label="عميلات موثوقات" value={summary.trusted} tone="positive" />
        <SummaryCard label="عليهن متبقي" value={summary.withBalance} tone={summary.withBalance > 0 ? 'warning' : 'default'} />
        <SummaryCard label="تنبيه أو حظر" value={summary.blockedOrWarning} tone={summary.blockedOrWarning > 0 ? 'danger' : 'default'} />
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="grid gap-3 lg:grid-cols-[1fr_180px_180px]">
          <label className="relative block">
            <span className="sr-only">البحث في العميلات</span>
            <Search aria-hidden="true" className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={filters.search}
              onChange={(event) => setFilters((current) => ({ ...current, search: event.target.value }))}
              placeholder="ابحثي بالاسم أو الهاتف أو العنوان"
              className="h-12 w-full rounded-xl border border-slate-200 bg-stone-50 pr-11 text-sm outline-none transition focus-visible:border-amber-500 focus-visible:ring-2 focus-visible:ring-amber-500/30"
            />
          </label>

          <label>
            <span className="sr-only">تصنيف العميلة</span>
            <select
              value={filters.status}
              onChange={(event) => setFilters((current) => ({ ...current, status: event.target.value as CustomerFilters['status'] }))}
              className="h-12 w-full rounded-xl border border-slate-200 bg-stone-50 px-3 text-sm outline-none transition focus-visible:border-amber-500 focus-visible:ring-2 focus-visible:ring-amber-500/30"
            >
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {status === 'all' ? 'كل التصنيفات' : statusLabels[status]}
                </option>
              ))}
            </select>
          </label>

          <label>
            <span className="sr-only">رصيد العميلة</span>
            <select
              value={filters.balance}
              onChange={(event) => setFilters((current) => ({ ...current, balance: event.target.value as CustomerFilters['balance'] }))}
              className="h-12 w-full rounded-xl border border-slate-200 bg-stone-50 px-3 text-sm outline-none transition focus-visible:border-amber-500 focus-visible:ring-2 focus-visible:ring-amber-500/30"
            >
              <option value="all">كل الأرصدة</option>
              <option value="with_balance">عليهن متبقي</option>
              <option value="clear">بدون متبقي</option>
            </select>
          </label>
        </div>
      </div>

      {filteredCustomers.length > 0 ? (
        <div className="grid gap-5 xl:grid-cols-2">
          {filteredCustomers.map((customer) => (
            <CustomerCard key={customer.id} customer={customer} />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center shadow-sm">
          <CircleAlert aria-hidden="true" className="mx-auto h-10 w-10 text-amber-700" />
          <p className="mt-4 text-lg font-bold text-slate-950">
            {customers.length === 0 ? 'لا توجد عميلات حتى الآن' : 'لا توجد عميلات مطابقات'}
          </p>
          <p className="mt-2 text-sm text-slate-500">
            {customers.length === 0 ? 'ابدئي بإضافة أول عميلة وحفظ بيانات التواصل والمقاسات.' : 'غيّري البحث أو الفلاتر الحالية لعرض نتائج أخرى.'}
          </p>
          {customers.length === 0 && (
            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-xl bg-slate-950 px-4 py-2 text-sm font-bold text-white transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2"
            >
              <Plus aria-hidden="true" className="h-4 w-4" />
              إضافة أول عميلة
            </button>
          )}
        </div>
      )}

      <AddCustomerModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onCreated={handleCreated} />
    </section>
  );
}
