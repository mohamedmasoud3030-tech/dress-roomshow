import type { FormEvent } from 'react';
import { useEffect, useMemo, useState } from 'react';
import { Modal } from '../../components/shared/Modal';
import { UserFacingErrorAlert } from '../../components/shared/UserFacingErrorAlert';
import { MAX_NOTES_LENGTH, MIN_ZERO_AMOUNT, MONEY_STEP } from '../../shared/domain/businessRules';
import {
  AMBER_FOCUS_RING_CLASS_NAME,
  STACKED_FORM_FIELD_CLASS_NAME,
  STACKED_FORM_LABEL_CLASS_NAME,
} from '../../shared/domain/formConstants';
import { calculateReservationRemainingAmount, calculateReturnSettlement } from '../../shared/utils/financialCalculations.js';
import { formatMoneyOMR } from '../../shared/utils/format';
import { BASIC_PAYMENT_METHOD_LABELS, PAYMENT_METHODS } from '../payments/payment.constants';
import { getPayments } from '../payments/payment.service';
import type { PaymentMethod } from '../payments/payment.types';
import { getReservations } from '../reservations/reservation.service';
import type { Reservation } from '../reservations/reservation.types';
import { completeDelivery, completeReturn } from './deliveryReturn.operations';
import type { DeliveryReturnRecord } from './deliveryReturn.types';

type Props = { open: boolean; onClose: () => void; onCompleted: (record: DeliveryReturnRecord) => void };
type Operation = 'delivery' | 'return';
type NextDressStatus = 'available' | 'laundry' | 'maintenance' | 'damaged';
type Form = {
  operation: Operation;
  reservationNumber: string;
  dateTime: string;
  condition: string;
  lateFee: string;
  damageFee: string;
  refundMethod: PaymentMethod;
  nextDressStatus: NextDressStatus;
  notes: string;
};

function getCurrentDateTimeLocal(): string {
  const date = new Date();
  const offsetDate = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return offsetDate.toISOString().slice(0, 16);
}

function defaults(operation: Operation = 'delivery'): Form {
  return {
    operation,
    reservationNumber: '',
    dateTime: getCurrentDateTimeLocal(),
    condition: '',
    lateFee: '0',
    damageFee: '0',
    refundMethod: 'cash',
    nextDressStatus: 'laundry',
    notes: '',
  };
}

function parseAmount(value: string): number {
  const amount = Number(value);
  return Number.isFinite(amount) && amount >= 0 ? amount : 0;
}

function getEligibleReservations(operation: Operation): Reservation[] {
  return getReservations().filter((item) =>
    operation === 'delivery'
      ? ['pending', 'confirmed'].includes(item.status)
      : ['delivered', 'overdue'].includes(item.status),
  );
}

function getReturnPreview(reservation: Reservation | undefined, lateFee: number, damageFee: number) {
  if (!reservation) return null;

  const reservationPayments = getPayments().filter((payment) => payment.reservationNumber === reservation.reservationNumber);
  const depositCollected = Math.min(
    reservation.depositAmount,
    reservationPayments
      .filter((payment) => payment.type === 'deposit' && payment.direction === 'income')
      .reduce((total, payment) => total + payment.amount, 0),
  );
  const totalCollected = reservationPayments
    .filter((payment) => payment.direction === 'income')
    .reduce((total, payment) => total + payment.amount, 0);
  const previouslyRefundedAmount = reservationPayments
    .filter((payment) => payment.direction === 'refund')
    .reduce((total, payment) => total + payment.amount, 0);
  const previouslyRefundedDepositAmount = reservationPayments
    .filter((payment) => payment.type === 'refund' && payment.direction === 'refund' && payment.source === 'return')
    .reduce((total, payment) => total + payment.amount, 0);
  const settlement = calculateReturnSettlement({
    depositAmount: reservation.depositAmount,
    depositCollected,
    totalCollected,
    previouslyRefundedAmount,
    previouslyRefundedDepositAmount,
    lateFee,
    damageFee,
  });
  const remainingAfterReturn = calculateReservationRemainingAmount({
    totalAmount: reservation.totalAmount,
    assessedFeesAmount: (reservation.assessedFeesAmount ?? 0) + settlement.assessedFeesAmount,
    paidAmount: reservation.paidAmount,
    settledDepositAmount: (reservation.settledDepositAmount ?? 0) + settlement.settledDepositAmount,
    refundedAmount: (reservation.refundedAmount ?? 0) + settlement.refundAmount,
  });

  return { settlement, remainingAfterReturn };
}

export function DeliveryReturnModal({ open, onClose, onCompleted }: Props) {
  const [form, setForm] = useState<Form>(() => defaults());
  const [error, setError] = useState<unknown>(null);
  const lateFee = parseAmount(form.lateFee);
  const damageFee = parseAmount(form.damageFee);
  const reservations = useMemo(() => getEligibleReservations(form.operation), [open, form.operation]);
  const selectedReservation = reservations.find((item) => item.reservationNumber === form.reservationNumber);
  const returnPreview = useMemo(
    () => getReturnPreview(selectedReservation, lateFee, damageFee),
    [selectedReservation, lateFee, damageFee],
  );

  useEffect(() => {
    if (!open) return;
    setForm(defaults());
    setError(null);
  }, [open]);

  const updateOperation = (operation: Operation) => {
    setForm(defaults(operation));
    setError(null);
  };

  const close = () => {
    setForm(defaults());
    setError(null);
    onClose();
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    try {
      const record = form.operation === 'delivery'
        ? completeDelivery({
            reservationNumber: form.reservationNumber,
            deliveryDateTime: form.dateTime,
            deliveryCondition: form.condition,
            notes: form.notes,
          })
        : completeReturn({
            reservationNumber: form.reservationNumber,
            returnDateTime: form.dateTime,
            returnCondition: form.condition,
            lateFee,
            damageFee,
            refundMethod: form.refundMethod,
            nextDressStatus: form.nextDressStatus,
            notes: form.notes,
          });
      onCompleted(record);
      close();
    } catch (reason: unknown) {
      setError(reason);
    }
  };

  return (
    <Modal open={open} onClose={close} title="تسجيل تسليم أو استرجاع" className="max-w-3xl">
      <form onSubmit={submit} className="space-y-5" noValidate>
        {error !== null && (
          <UserFacingErrorAlert error={error} fallback="تعذر حفظ العملية." />
        )}

        <div className="grid gap-3 rounded-3xl bg-slate-950 p-2 text-sm font-bold text-white sm:grid-cols-2">
          <button
            type="button"
            onClick={() => updateOperation('delivery')}
            className={`min-h-11 rounded-2xl px-4 transition ${AMBER_FOCUS_RING_CLASS_NAME} ${form.operation === 'delivery' ? 'bg-amber-300 text-slate-950' : 'text-slate-300 hover:bg-white/10'}`}
          >
            تسليم فستان للعميلة
          </button>
          <button
            type="button"
            onClick={() => updateOperation('return')}
            className={`min-h-11 rounded-2xl px-4 transition ${AMBER_FOCUS_RING_CLASS_NAME} ${form.operation === 'return' ? 'bg-amber-300 text-slate-950' : 'text-slate-300 hover:bg-white/10'}`}
          >
            استرجاع فستان من العميلة
          </button>
        </div>

        <div className="grid gap-4 md:grid-cols-[1.3fr_1fr]">
          <label className={STACKED_FORM_LABEL_CLASS_NAME}>
            الحجز
            <select
              required
              value={form.reservationNumber}
              onChange={(event) => setForm((current) => ({ ...current, reservationNumber: event.target.value }))}
              className={STACKED_FORM_FIELD_CLASS_NAME}
            >
              <option value="">اختاري الحجز</option>
              {reservations.map((item) => (
                <option key={item.id} value={item.reservationNumber}>
                  {item.reservationNumber} - {item.customerName} - {item.dressCode}
                </option>
              ))}
            </select>
          </label>

          <label className={STACKED_FORM_LABEL_CLASS_NAME}>
            التاريخ والوقت
            <input
              required
              type="datetime-local"
              max={getCurrentDateTimeLocal()}
              value={form.dateTime}
              onChange={(event) => setForm((current) => ({ ...current, dateTime: event.target.value }))}
              className={STACKED_FORM_FIELD_CLASS_NAME}
            />
          </label>
        </div>

        {selectedReservation && (
          <div className="grid gap-3 rounded-3xl border border-amber-100 bg-amber-50/80 p-4 text-sm text-slate-700 sm:grid-cols-4">
            <div>
              <p className="text-xs font-bold text-amber-800">العميلة</p>
              <p className="mt-1 font-extrabold text-slate-950">{selectedReservation.customerName}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-amber-800">الفستان</p>
              <p className="mt-1 font-extrabold text-slate-950">{selectedReservation.dressCode}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-amber-800">الإرجاع المجدول</p>
              <p className="mt-1 font-extrabold text-slate-950">{selectedReservation.returnDate}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-amber-800">الرصيد الحالي</p>
              <p className="mt-1 font-extrabold text-slate-950">{formatMoneyOMR(selectedReservation.remainingAmount)}</p>
            </div>
          </div>
        )}

        <label className={STACKED_FORM_LABEL_CLASS_NAME}>
          حالة الفستان
          <textarea
            rows={2}
            value={form.condition}
            onChange={(event) => setForm((current) => ({ ...current, condition: event.target.value }))}
            className={STACKED_FORM_FIELD_CLASS_NAME}
            placeholder={form.operation === 'delivery' ? 'مثال: تم التسليم بحالة ممتازة مع الشال.' : 'مثال: يحتاج تنظيف بسيط عند الذيل.'}
          />
        </label>

        {form.operation === 'return' && (
          <div className="space-y-4 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="grid gap-4 md:grid-cols-2">
              <label className={STACKED_FORM_LABEL_CLASS_NAME}>
                رسوم التأخير
                <input
                  type="number"
                  min={MIN_ZERO_AMOUNT}
                  step={MONEY_STEP}
                  inputMode="decimal"
                  value={form.lateFee}
                  onChange={(event) => setForm((current) => ({ ...current, lateFee: event.target.value }))}
                  className={STACKED_FORM_FIELD_CLASS_NAME}
                />
              </label>
              <label className={STACKED_FORM_LABEL_CLASS_NAME}>
                رسوم الضرر
                <input
                  type="number"
                  min={MIN_ZERO_AMOUNT}
                  step={MONEY_STEP}
                  inputMode="decimal"
                  value={form.damageFee}
                  onChange={(event) => setForm((current) => ({ ...current, damageFee: event.target.value }))}
                  className={STACKED_FORM_FIELD_CLASS_NAME}
                />
              </label>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <label className={STACKED_FORM_LABEL_CLASS_NAME}>
                وسيلة رد العربون
                <select
                  value={form.refundMethod}
                  onChange={(event) => setForm((current) => ({ ...current, refundMethod: event.target.value as PaymentMethod }))}
                  className={STACKED_FORM_FIELD_CLASS_NAME}
                >
                  {PAYMENT_METHODS.map((method) => (
                    <option key={method} value={method}>
                      {BASIC_PAYMENT_METHOD_LABELS[method]}
                    </option>
                  ))}
                </select>
              </label>
              <label className={STACKED_FORM_LABEL_CLASS_NAME}>
                حالة الفستان التالية
                <select
                  value={form.nextDressStatus}
                  onChange={(event) => setForm((current) => ({ ...current, nextDressStatus: event.target.value as NextDressStatus }))}
                  className={STACKED_FORM_FIELD_CLASS_NAME}
                >
                  <option value="available">متاح مباشرة</option>
                  <option value="laundry">إلى المغسلة</option>
                  <option value="maintenance">إلى التعديل أو الصيانة</option>
                  <option value="damaged">تالف أو متضرر</option>
                </select>
              </label>
            </div>

            {returnPreview && (
              <div className="grid gap-3 rounded-2xl bg-slate-50 p-4 text-sm sm:grid-cols-4">
                <div>
                  <p className="text-xs font-bold text-slate-500">رسوم مثبتة</p>
                  <p className="mt-1 font-extrabold text-slate-950">{formatMoneyOMR(returnPreview.settlement.assessedFeesAmount)}</p>
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500">عربون محتجز</p>
                  <p className="mt-1 font-extrabold text-amber-700">{formatMoneyOMR(returnPreview.settlement.retainedDepositAmount)}</p>
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500">رد متوقع</p>
                  <p className="mt-1 font-extrabold text-emerald-700">{formatMoneyOMR(returnPreview.settlement.refundAmount)}</p>
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500">متبقي بعد الاسترجاع</p>
                  <p className="mt-1 font-extrabold text-rose-700">{formatMoneyOMR(returnPreview.remainingAfterReturn)}</p>
                </div>
              </div>
            )}
          </div>
        )}

        <label className={STACKED_FORM_LABEL_CLASS_NAME}>
          ملاحظات
          <textarea
            rows={3}
            maxLength={MAX_NOTES_LENGTH}
            value={form.notes}
            onChange={(event) => setForm((current) => ({ ...current, notes: event.target.value }))}
            className={STACKED_FORM_FIELD_CLASS_NAME}
            placeholder="ملاحظات داخلية اختيارية عن العملية"
          />
        </label>

        {reservations.length === 0 && (
          <p className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-sm font-bold text-amber-800">
            لا توجد حجوزات مؤهلة لهذه العملية حالياً.
          </p>
        )}

        <div className="flex flex-col-reverse gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={close}
            className={`min-h-11 rounded-xl border border-slate-300 px-5 py-2 text-sm font-bold text-slate-700 transition hover:bg-stone-100 ${AMBER_FOCUS_RING_CLASS_NAME}`}
          >
            إلغاء
          </button>
          <button
            type="submit"
            disabled={reservations.length === 0}
            className={`min-h-11 rounded-xl bg-slate-950 px-5 py-2 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50 ${AMBER_FOCUS_RING_CLASS_NAME}`}
          >
            حفظ العملية
          </button>
        </div>
      </form>
    </Modal>
  );
}
